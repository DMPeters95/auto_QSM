#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	char *file_name_1, *file_name_2, *file_name_out;
	short *data_1, *data_2, *data_out;
	long n_int, size_file;
	FILE *fp;
    int i;

    file_name_1 = argv[1];
    file_name_2 = argv[2];
    file_name_out = argv[3];

    fp = fopen(file_name_1,  "rb");
    fseek(fp, 0L, SEEK_END);
	size_file = ftell(fp);
	n_int = size_file/2;
	fclose(fp);



	data_1 = (short *) malloc(n_int * sizeof(short));
	data_2 = (short *) malloc(n_int * sizeof(short));
	data_out = (short *) malloc(n_int * sizeof(short));
	
	/* Read file 1 */
	fp = fopen(file_name_1,  "rb");
	fread(data_1, sizeof(short), n_int, fp);
	fclose(fp);

	/* Read file 2 */
	fp = fopen(file_name_2,  "rb");
	fread(data_2, sizeof(short), n_int, fp);
	fclose(fp);

	/* Average data 1 and data 2 */
	for (i = 0; i < n_int; i++) {
		data_out[i] = (short)((((int)data_1[i]) + ((int)data_2[i])) / 2);
	}

	/* Write file output */
	fp = fopen(file_name_out,  "wb");
	fwrite(data_out, sizeof(short), n_int, fp);
	fclose(fp);



	free(data_1);
	free(data_2);
	free(data_out);

    return 0;
}